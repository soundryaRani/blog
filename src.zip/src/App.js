import { Route, Routes } from 'react-router-dom';
import './App.css';
import { Login } from './Login';
import { PostBlog } from './PostBlog';
import Signup from './Signup';
import img from './image/blog-banner.jpeg'
function App() {
  return (
    <div className="App">
    <h2>BLOG</h2>
    <Routes>
    
      <Route path='/' element={<Signup/>}/>
      <Route path='/Login' element={<Login/>}/>
      <Route path='/PostBlog' element={<PostBlog/>}/>
    </Routes>
    </div>
  );
}
export default App;
