import './PostBlog.css'
import React, { useState } from "react";
import {useNavigate } from 'react-router-dom';
export const PostBlog = () => {
    const navigate=useNavigate();
    const [comment, setComment] = useState("");
    const [output, setOutput] = useState([]);
    const [img, setImg] = useState("");
    const [button,buttonHandler]=useState("")
       // functions for taking the value from input boxes
  const commentHandler = (e) => {
    setComment(e.target.value);
  };
  const UploadFileHandler = (event) => {
    // upload abd display image
    let p1=(URL.createObjectURL(event.target.files[0]));
    setImg(p1)
  };
    //   post button function
      const postHandler = (e) => {
        setComment("")
        var obj = {
          data: comment,
          image:img,
          id: Math.random(),
        };
        console.log(obj);
        if (obj.data === "") {
          alert("Please write something");
        } else {
          setOutput([...output, obj]);
        }
      };
      //   edit function
  const editHandler = (val) => {
    for (let i = 0; i < output.length; i++) {
  
      document.getElementById("Submit_id").disabled = true;
      if (val === output[i].id) {
        setComment([output[i].data]);
        output.splice(i, 1);
      }
    }
  };
//   delete function
  const deleteHandler = (val) => {
    for (let i = 0; i < output.length; i++) {
      if (val === output[i].id) {
        output.splice(i, 1);
      }
    }
    setOutput([...output]);
  };
//   back to main page
  const backButtonHandler=()=>{
    navigate('/')
  }
  return (
    <>
    <center>
    <div className="comment">
        <textarea
          name=""
          id=""
          value={comment}
          onChange={commentHandler}
          placeholder="write comment Here"
        ></textarea>
        <br />
        <label for="upload">Upload a file</label>
      <input type="file" name="photo" id="files" onChange={UploadFileHandler} />
        {/* <input id="files" type="file" onChange={UploadFileHandler} /> */}
        <br />
        <button className="postbutton" onClick={postHandler}>
          post
        </button>
        <ul>
            {output.map((element) => (
              <div className="Posted">
              <div className="displayimg">
              <img id="img1" src={element.image} alt="" /></div> 
              <div className='CaptionDiv'>{element.data}  {""}{" "} <br />
                <button id="Submit_id"  onClick={() => editHandler(element.id)}>
                ✏️
                </button>{" "} <br /> <br /> <br /> 
                <button onClick={() => deleteHandler(element.id)}>
                ❌
                </button>{" "}
                </div>
              </div>
            ))}
          </ul>{" "}
    </div>
    </center>
    </>
  )
}
